Indice dei programmi:
=====================

Esempi:
-------
testEncapsulation.cpp --> Programma per capire cosa si intende per incapsulamento
testInheritance.cpp   --> Programma per capire cosa si intende per ereditarietà
testPolymorphism.cpp  --> Programma per capire cosa si intende per polimorfismo

Esercizi:
---------
esercizio01.cpp       --> Realizzazione della classe istogramma
istogramma.cc
istogramma.h

testConst.cpp	      --> Esercizio sui const (trovare gli errori e correggerli)

Approfondimenti:
---------
testStruct.cpp        --> Programma per capire il funzionamento delle struct
