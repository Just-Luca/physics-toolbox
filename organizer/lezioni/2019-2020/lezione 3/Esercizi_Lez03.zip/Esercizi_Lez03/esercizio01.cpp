/*
c++ -o esercizio01 esercizio01.cpp istogramma.cc
*/

#include <random>
#include "istogramma.h"


int main()
{
  std::default_random_engine generator;

  double mean, sigma;
  std::cout << "Inserire mean e sigma della Gaussiana con cui generare i numeri: ";
  std::cin >> mean >> sigma;
  std::normal_distribution<double> pdfGauss(mean,sigma);

  int N;
  std::cout << "Inserire quanti numeri casuali vuoi generare: ";
  std::cin >> N;

  double min, max;
  std::cout << "Inserire gli estremi dell'istogramma [min,max): ";
  std::cin >> min >> max;

  int nBin;
  std::cout << "Inserire il numero di bin dell'istogramma: ";
  std::cin >> nBin;

  // Constructor
  istogramma histo(nBin, min, max);

  // Riempie l'istogramma
  for (int i = 0; i < N; i++)
    histo.Fill(pdfGauss(generator));

  // Print
  std::cout << "Mean = "       << std::setprecision(5) << histo.GetMean() << std::endl;
  std::cout << "RMS  = "       << std::setprecision(5) << histo.GetRMS()  << std::endl;
  std::cout << "Overflow   = " << histo.GetOverflow()  << std::endl;
  std::cout << "Underflow  = " << histo.GetUnderflow() << std::endl;
  std::cout << "Max counts = " << histo.GetMax()       << std::endl;
  std::cout << "Integral ["    << min << ", " << max << "] = " << histo.GetIntegral() << std::endl;
  histo.Print();

  return 0;
}
