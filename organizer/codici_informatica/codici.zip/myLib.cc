#include <cstdlib>
#include <iostream>
#include <cmath>

double rand_range (double min, double max) {
	
	return min + (max - min) * rand() / (1. * RAND_MAX);
}


