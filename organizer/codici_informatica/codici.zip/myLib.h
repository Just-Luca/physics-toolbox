#ifndef myLib_h
#define myLib_h

double rand_range (double min, double max);

#endif
