/*
c++ -o esercizio03 esercizio03.cpp

Esercizio: utilizzate new e delete per creare e distruggere
           una variabile double ed un array di double
*/

#include <iostream>

int main()
{
  double* valore = new double(1.5);
  std::cout << "Valore creato con la new: " << *valore << std::endl;
  delete valore;

  int dim = 5;
  double* myArr = new double[dim];
  for (int i = 0; i < dim; i++)
    {
      myArr[i] = 2.2 * i;
      std::cout << "Valore [" << i << "] dell'array creato con la new: "
                << myArr[i] << std::endl;
    }
  delete [] myArr;

  return 0;
}
