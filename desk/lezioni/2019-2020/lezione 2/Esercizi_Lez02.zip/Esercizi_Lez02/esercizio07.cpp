/*
c++ -o esercizio07 esercizio07.cpp

Esercizio: riscrivere la creaArray senza fare uso dell'istruzione return
*/

#include <iostream>


// ##########################
// # Solution with pointers #
// ##########################
void creaArray (int dim, int** array)
{
  *array = new int[dim];
}


// ############################
// # Solution with references #
// ############################
// void creaArray (int dim, int*& array)
// {
//   array = new int[dim];
// }


int main()
{
  int dim = 0;
  std::cout << "Insert the dimension of the array: ";
  std::cin >> dim;

  if (dim < 0)
  {
    std::cout << "Negative number: " << dim << std::endl;
    return -1;
  }


  // ###################################
  // # Dynamic allocation of the array #
  // ###################################
  int* myArr;


  // ##########################
  // # Solution with pointers #
  // ##########################
  creaArray(dim,&myArr);


  // ############################
  // # Solution with references #
  // ############################
  // creaArray(dim,myArr);


  // Fill the array
  for (int i = 0; i < dim; i++)
    myArr[i] = i+1;

  // Print the elements of the array
  for (int i = 0; i < dim; i++)
    std::cout << "Content of the cell " << i << " : " << myArr[i] << std::endl;

  delete[] myArr;

  return 0;
}
