/*
c++ -o esercizio02 esercizio02.cpp

Esercizio: dichiarate un puntatore e poi cercate di assegnargli direttamente
           un valore numerico. Cosa succede? Perche`?
*/

#include <iostream>

int main()
{
  int* pointer;

  pointer = 5;
  std::cout << "Valore scritto in pointer: " << pointer << std::endl;

  return 0;
}
