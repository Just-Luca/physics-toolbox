/*
c++ -o esempio03 esempio03.cpp
*/

#include <iostream>

int main()
{
  int dim = 0;
  std::cout << "Inserire la dimensione del vettore: ";
  std::cin >> dim;

  if (dim < 0)
    {
      std::cout << "Numero negativo:" << dim << std::endl;
      return 1;
    }

  // Alloca dinamicamente un vettore di dim posti
  int* myArr = new int[dim];

  // Riempie l'array
  for (int i = 0; i < dim; i++)
    {
      myArr[i] = i+1;
    }

  // Stampa i posti pari dell'array
  std::cout << "Uso l'array\n";
  for (int i = 0; i < dim; i++)
    {
      if (i%2 == 0)
        {
          std::cout << "Alla posizione " << i << " c'è " << myArr[i] << std::endl;
        }
    }

  // Fa lo stesso con i puntatori
  std::cout << "Uso i puntatori\n";
  for (int* p = myArr; (p-myArr) < dim; p++)
    {
      if ((p-myArr)%2 == 0)
        {
          std::cout << "Alla posizione " << p-myArr << " c'è " << *p << std::endl;
        }
    }

  delete[] myArr;

  return 0;
}
