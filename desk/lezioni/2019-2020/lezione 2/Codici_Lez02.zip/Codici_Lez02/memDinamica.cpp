/*
c++ -o memDinamica memDinamica.cpp
*/

#include <iostream>

int* creaArray(int dim)
{
  int* array = new int[dim];
  return array;
}

int main()
{
  int dim = 0;

  std::cout << "Inserire la dimensione dell'array: ";
  std::cin >> dim;

  if (dim < 0)
    {
      std::cout << "Numero negativo: " << dim << std::endl;
      return 1;
    }

  // Alloca dinamicamente un array di dim celle
  int* myArr = creaArray(dim);

  // Riempi l'array
  for (int i = 0; i < dim; i++)
    myArr[i] = i+1;

  // Stampa gli elementi dell'array
  for (int i = 0; i < dim; i++)
    {
      std::cout << "Contenuto della cella " << i << " : " << myArr[i] << std::endl;
    }

  delete[] myArr;

  return 0;
}
