/*
c++ -o esempio01 esempio01.cpp
*/

#include <iostream>

int main()
{
  int* pointer; // Dichiara un puntatore senza inizializzarlo
  std::cout << "Indirizzo a cui punta pointer " << pointer << std::endl;

  pointer = NULL; // Setta pointer a puntare all'indirizzo nullo
  std::cout << "Indirizzo nullo a cui punta pointer " << pointer << std::endl;

  int num = 5;
  pointer = &num;  // Setta pointer all'indirizzo di num
  std::cout << "Num valore " << num << std::endl;
  std::cout << "Valore puntato da pointer " << *pointer << std::endl;
  std::cout << "Indirizzo di num " << &num << std::endl;
  std::cout << "Valore scritto in pointer " << pointer << std::endl;

  // Qualunque operazione fatta con *pointer viene fatta "sulla variabile a cui punta pointer", quindi su num
  *pointer = 100;
  std::cout << "num is: " << num << std::endl;

  (*pointer)++;
  std::cout << "num is: " << num << std::endl;

  (*pointer)--;
  std::cout << "num is: " << num << std::endl;

  return 0;
}
